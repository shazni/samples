# discovery-client
ESB-G-Reg Service Discovery Client

Documentation available on : [https://cnapagoda.blogspot.com](https://cnapagoda.blogspot.com/2016/08/service-discovery-client-with-wso2.html)


